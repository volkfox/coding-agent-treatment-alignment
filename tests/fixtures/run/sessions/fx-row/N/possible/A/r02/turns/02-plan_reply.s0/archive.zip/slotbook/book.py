class BookingError(Exception):
    pass
a_1 = 1
a_2 = 2
a_3 = 3
a_4 = 4
a_5 = 5
a_6 = 6
