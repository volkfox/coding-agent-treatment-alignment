class BookingError(Exception):
    pass
a_1 = 1
a_2 = 2
a_3 = 3
a_4 = 4
b_1 = 1
b_2 = 2
c_1 = 1
c_2 = 2
c_3 = 3
d_1 = 1
d_2 = 2
d_3 = 3
d_4 = 4
e_1 = 1
e_2 = 2
f_1 = 1
