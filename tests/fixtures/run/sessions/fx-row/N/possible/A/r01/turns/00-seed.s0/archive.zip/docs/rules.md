One store read per call.
A closed room refuses bookings.
