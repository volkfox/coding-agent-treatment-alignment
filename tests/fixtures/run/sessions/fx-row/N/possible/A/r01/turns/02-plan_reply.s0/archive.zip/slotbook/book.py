class BookingError(Exception):
    pass
a_1 = 1
a_2 = 2
a_3 = 3
a_4 = 4
b_1 = 1
b_2 = 2
