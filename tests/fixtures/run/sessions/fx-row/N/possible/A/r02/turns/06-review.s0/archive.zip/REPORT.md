# Report
Part A done.
Assumption: none.
U2: __version__ was stale.
R1: met
R2: met
R3: met
R4: met
R5: met
R6: met
R7: met
