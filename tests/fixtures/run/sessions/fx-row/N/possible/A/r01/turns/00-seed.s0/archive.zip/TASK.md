# Task
Add book and free_spans to slotbook/book.py.
Forks: FORK-1, FORK-2.
