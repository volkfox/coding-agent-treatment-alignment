# Changelog

## 0.9.1
Fixed: reminder-email crash.

## 0.9.0
Added: plan tiers.
## 0.10.0
Added: booking.

