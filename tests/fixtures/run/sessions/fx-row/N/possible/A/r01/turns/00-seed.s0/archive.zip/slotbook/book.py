class BookingError(Exception):
    pass
