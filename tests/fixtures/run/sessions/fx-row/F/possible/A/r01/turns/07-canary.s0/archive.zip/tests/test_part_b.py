import unittest


class PartB(unittest.TestCase):
    def test_r6(self):
        self.assertTrue(True)
