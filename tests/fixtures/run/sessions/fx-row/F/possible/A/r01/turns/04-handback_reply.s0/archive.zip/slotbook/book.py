class BookingError(Exception):
    pass
a_1 = 1
a_2 = 2
a_3 = 3
a_4 = 4
b_1 = 1
c_1 = 1
c_2 = 2
d_1 = 1
d_2 = 2
d_3 = 3
d_4 = 4
d_5 = 5
