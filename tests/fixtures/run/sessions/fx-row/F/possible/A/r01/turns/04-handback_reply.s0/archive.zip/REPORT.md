# Report
Part A done.
