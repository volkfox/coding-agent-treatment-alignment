import unittest


class PartA(unittest.TestCase):
    def test_r1(self):
        self.assertTrue(True)
