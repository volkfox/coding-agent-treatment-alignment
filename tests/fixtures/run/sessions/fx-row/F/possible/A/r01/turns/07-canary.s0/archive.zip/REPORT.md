# Report
Part A done.
R1: met
R2: met
R3: met
R4: met
R5: met
R6: met
R7: met
