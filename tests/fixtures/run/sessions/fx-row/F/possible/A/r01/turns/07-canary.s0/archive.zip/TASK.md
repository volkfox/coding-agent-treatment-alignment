# Task
Add book and free_spans to slotbook/book.py.
Forks: FORK-1, FORK-2.
Part B: add enqueue and cancel. Fork: FORK-3.
